
# ТЕХНОЛОГИИ АНАЛИЗА ПРОСТРАНСТВА
<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

## АНАЛИЗ ПЛАНА ПОМЕЩЕНИЯ

<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

#### DeCodingSpaces

http://decodingspaces.de/

https://vimeo.com/user2925067

https://vimeo.com/user5409119

софт пространственного анализа


```python
from IPython.display import VimeoVideo
VimeoVideo('89392450',width=700, height=600)
```





        <iframe
            width="700"
            height="600"
            src="https://player.vimeo.com/video/89392450"
            frameborder="0"
            allowfullscreen
        ></iframe>
        



<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

#### ETH ArchTec Lab



```python
from IPython.display import YouTubeVideo
YouTubeVideo('ULMF8NO5vQM',width=900, height=600)
```





        <iframe
            width="900"
            height="600"
            src="https://www.youtube.com/embed/ULMF8NO5vQM"
            frameborder="0"
            allowfullscreen
        ></iframe>
        



<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

#### Autodesk University Research - Autodesk Office Toronto

http://autodesk.typepad.com/bimtoolbox/2017/06/generative-design-applied-on-buildings.html

https://www.youtube.com/watch?v=TmAY6qycBsk

https://medium.com/autodesk-university/generative-design-for-architectural-space-planning-9f82cf5dcdc0



```python
from IPython.display import VimeoVideo
VimeoVideo('193915345',width=900, height=600)
```





        <iframe
            width="900"
            height="600"
            src="https://player.vimeo.com/video/193915345"
            frameborder="0"
            allowfullscreen
        ></iframe>
        



### СТИЛЬ РАБОТЫ

### СТЕПЕНЬ ОТВЛЕКАНИЯ

### ВИД НА УЛИЦУ

### СВЯЗНОСТЬ

### СОСЕДСТВО (ПРЕДПОЧТЕНИЕ)

### СВЕТ ИЗ ОКОН

##### СОЛНЕЧНАЯ ИНСОЛЯЦИЯ

##### ЕСТЕСТВЕННОЕ ОСВЕЩЕНИЕ

<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

### АНАЛИЗ СЕРДЕЧНОГО РИТМА 

надо почитать

http://med88.ru/kardiologija/diagnostika/holter/

<hr style="height:4px;border:none;color:stillblue;background-color:black;" />

# ГЕНЕРАЦИЯ БЕСКОНЕЧНОСТИ

#### MONSTROCITY

http://mariasni.com/project/monstocity/
http://www.mas.caad.arch.ethz.ch/blog/grammar-machines/index.html

РЕЗУЛЬТАТ ТРЁХДНЕВНОГО ВОРКШОПА: ПРИМИНЕНИЕ МЕТОДОВ Shape Grammar В Processing


```python
from IPython.display import VimeoVideo
VimeoVideo('54754817',width=1000, height=600)
```





        <iframe
            width="1000"
            height="600"
            src="https://player.vimeo.com/video/54754817"
            frameborder="0"
            allowfullscreen
        ></iframe>
        



<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

#### CITY ENGINE

http://www.esri.com/software/cityengine

СОФТ, СОЗДАННЫЙ ДЛЯ ГЕНЕРАЦИИ ГОРОДСКОГО ЛАНДШАФТА В ИГРАХ И ФИЛЬМАХ
СЕЙЧАС ИСПОЛЬЗУЕТСЯ ДЛЯ ГОРОДСКОГО АНАЛИЗА, МОДЕЛИРОВАНИЯ, ВИЗУАЛИЗАЦИИ... ПРОДАЖИ ГОРОДОВ


```python
from IPython.display import YouTubeVideo
YouTubeVideo('aFRqSJFp-I0',width=1000, height=600)
```





        <iframe
            width="1000"
            height="600"
            src="https://www.youtube.com/embed/aFRqSJFp-I0"
            frameborder="0"
            allowfullscreen
        ></iframe>
        



<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

#### LUMION_8

https://lumion.com/

ТОПОВЫЙ РЕНДЕРЕР


```python
from IPython.display import YouTubeVideo
YouTubeVideo('N5TLwzDAaf4',width=900, height=600)
```





        <iframe
            width="900"
            height="600"
            src="https://www.youtube.com/embed/N5TLwzDAaf4"
            frameborder="0"
            allowfullscreen
        ></iframe>
        



<hr style="height:2px;border:none;color:stillblue;background-color:black;" />

#### HOME DESIGNER

https://www.homedesignersoftware.com/

DIY СОФТ МОДЕЛИРОВАНИЯ ЗДАНИЙ


```python
from IPython.display import YouTubeVideo
YouTubeVideo('YEH_EuNcFdQ',width=900, height=600)
```





        <iframe
            width="900"
            height="600"
            src="https://www.youtube.com/embed/YEH_EuNcFdQ"
            frameborder="0"
            allowfullscreen
        ></iframe>
        



<hr style="height:2px;border:none;color:stillblue;background-color:black;" />
